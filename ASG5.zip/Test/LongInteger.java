
/**
* @author Aigerim Alykulova
*/


/**
 * Represents a LongInteger with various utility methods for performing operations
 * on long integer values such as checking for even, odd, and prime status, and parsing strings.
 */
public class LongInteger {
    private long value; // Stores the value of this LongInteger instance.

    /**
     * Constructor that initializes the LongInteger with a specified value.
     * 
     * @param value the initial value of this LongInteger instance
     */
    public LongInteger(long value) {
        this.value = value;
    }

    /**
     * Returns the value of this LongInteger.
     * 
     * @return the long value stored in this LongInteger
     */
    public long toLong() {
        return value;
    }

    /**
     * Checks if the current value of this LongInteger is even.
     * 
     * @return true if the value is even, false otherwise
     */
    public boolean isEven() {
        return isEven(value);
    }

    /**
     * Checks if the current value of this LongInteger is odd.
     * 
     * @return true if the value is odd, false otherwise
     */
    public boolean isOdd() {
        return isOdd(value);
    }

    /**
     * Checks if the current value of this LongInteger is prime.
     * 
     * @return true if the value is a prime number, false otherwise
     */
    public boolean isPrime() {
        return isPrime(value);
    }

    /**
     * Checks if a given long value is even.
     * 
     * @param n the long value to check
     * @return true if the given value is even, false otherwise
     */
    public static boolean isEven(long n) {
        return n % 2 == 0;
    }

    /**
     * Checks if a given long value is odd.
     * 
     * @param n the long value to check
     * @return true if the given value is odd, false otherwise
     */
    public static boolean isOdd(long n) {
        return n % 2 != 0;
    }

    /**
     * Checks if a given long value is a prime number.
     * 
     * @param n the long value to check
     * @return true if the given value is prime, false otherwise
     */
    public static boolean isPrime(long n) {
        if (n < 2) return false; // Prime numbers are greater than 1.
        for (long i = 2; i <= Math.sqrt(n); i++) { // Only check up to sqrt(n) for efficiency.
            if (n % i == 0) return false; // If divisible, not a prime number.
        }
        return true; // If no divisors found, n is prime.
    }

    /**
     * Compares this LongInteger's value to another long value.
     * 
     * @param otherValue the value to compare to
     * @return true if the values are equal, false otherwise
     */
    public boolean equals(long otherValue) {
        return this.value == otherValue;
    }

    /**
     * Compares this LongInteger's value to another LongInteger's value.
     * 
     * @param other the LongInteger to compare to
     * @return true if the values are equal, false otherwise
     */
    public boolean equals(LongInteger other) {
        return this.value == other.toLong();
    }

    /**
     * Parses a string and converts it into a long value. Handles optional negative sign,
     * underflow, and overflow for long values.
     * 
     * @param str the string to be parsed
     * @return the long value represented by the string
     * @throws IllegalArgumentException if the string is null, empty, or contains invalid characters
     */
    public static long parseLong(String str) {
        if (str == null || str.isEmpty()) {
            throw new IllegalArgumentException("Input string cannot be null or empty.");
        }

        boolean isNegative = str.charAt(0) == '-'; // Check if the number is negative.
        int startIndex = isNegative ? 1 : 0; // Start index for parsing digits.
        if (isNegative && str.length() == 1) {
            throw new IllegalArgumentException("Invalid number format.");
        }

        long result = 0;
        for (int i = startIndex; i < str.length(); i++) {
            char ch = str.charAt(i);
            if (!Character.isDigit(ch)) {
                throw new IllegalArgumentException("Invalid character found: " + ch);
            }

            int digit = ch - '0';
            if (isNegative) {
                // Check for underflow
                if (result < (Long.MIN_VALUE + digit) / 10) {
                    throw new IllegalArgumentException("Underflow detected.");
                }
                result = result * 10 - digit; // Accumulate result as negative value
            } else {
                // Check for overflow
                if (result > (Long.MAX_VALUE - digit) / 10) {
                    throw new IllegalArgumentException("Overflow detected.");
                }
                result = result * 10 + digit; // Accumulate result as positive value
            }
        }

        return result;
    }
}
