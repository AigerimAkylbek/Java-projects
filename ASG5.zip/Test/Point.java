
/**
* @author Aigerim Alykulova
*/

public class Point {
    // Instance variables representing the x and y coordinates of the point
    private double x;
    private double y;

    // No-argument constructor that initializes the point to (1, 1)
    public Point() {
        this.x = 1;
        this.y = 1;
    }

    // Constructor that accepts x and y coordinates as parameters
    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    // Accessor method for the x-coordinate
    public double getX() {
        return x;
    }

    // Accessor method for the y-coordinate
    public double getY() {
        return y;
    }

    // Mutator method for the x-coordinate
    public void setX(double x) {
        this.x = x;
    }

    // Mutator method for the y-coordinate
    public void setY(double y) {
        this.y = y;
    }

    // Method to move the point by a given change in x (dx) and y (dy)
    public void move(double dx, double dy) {
        this.x += dx;
        this.y += dy;
    }

    // Method to rotate the point 90 degrees clockwise around the origin
    public void rotate() {
        // Temporary variables for the new rotated coordinates
        double newX = y;
        double newY = -x;
        // Update the point's coordinates to the rotated values
        this.x = newX;
        this.y = newY;
    }
}
