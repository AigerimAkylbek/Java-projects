
/**
* @author Aigerim Alykulova
*/

public class RightTriangle {
    // Instance variables for the two legs of the triangle
    private double legA;
    private double legB;

    // No-argument constructor that initializes both legs to 1
    public RightTriangle() {
        this.legA = 1;
        this.legB = 1;
    }

    // Constructor that accepts leg values as parameters with validation
    public RightTriangle(double legA, double legB) {
        // Ensure both legs are positive, otherwise throw an exception
        if (legA <= 0 || legB <= 0) {
            throw new IllegalArgumentException("Legs must be positive.");
        }
        this.legA = legA;
        this.legB = legB;
    }

    // Accessor method for legA
    public double getLegA() {
        return legA;
    }

    // Accessor method for legB
    public double getLegB() {
        return legB;
    }

    // Mutator method for legA with validation
    public void setLegA(double legA) {
        // Ensure the new value is positive; otherwise, throw an exception
        if (legA <= 0) {
            throw new IllegalArgumentException("Leg must be positive.");
        }
        this.legA = legA;
    }

    // Mutator method for legB with validation
    public void setLegB(double legB) {
        // Ensure the new value is positive; otherwise, throw an exception
        if (legB <= 0) {
            throw new IllegalArgumentException("Leg must be positive.");
        }
        this.legB = legB;
    }

    // Method to calculate and return the hypotenuse of the right triangle
    public double getHypotenuse() {
        // Using Pythagorean theorem: hypotenuse = √(legA^2 + legB^2)
        return Math.sqrt((legA * legA) + (legB * legB));
    }

    // Method to calculate and return the area of the right triangle
    public double getArea() {
        // Area formula for a right triangle: (legA * legB) / 2
        return (legA * legB) / 2;
    }

    // Method to calculate and return the perimeter of the right triangle
    public double getPerimeter() {
        // Perimeter is the sum of both legs and the hypotenuse
        return legA + legB + getHypotenuse();
    }

    // Overridden toString method to display the legs of the triangle
    @Override
    public String toString() {
        return "legA = " + legA + ", legB = " + legB;
    }
}
