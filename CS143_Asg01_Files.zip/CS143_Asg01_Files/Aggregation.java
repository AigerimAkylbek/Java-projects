/**
* @author Aigerim Alykulova
**/

// Define a class named Aggregation
public class Aggregation {
    
   // Declare a private field named fractionField of type Fraction
    private Fraction fractionField;
   // Declare a private array field named arrayField containing objects of type Rectangle
    private Rectangle[] arrayField;
    // Declare a private field named doubleField of type double
    private double doubleField;
    
    // Non-argument constructor
    public Aggregation() {
        // Initialize fractionField with a new Fraction object representing 0/1
        this.fractionField = new Fraction(0, 1);
        // Initialize arrayField with an array containing a new Rectangle object with width and length both set to 1
        this.arrayField = new Rectangle[]{new Rectangle(1, 1)};
    
        this.doubleField = 0.0;
    }

    // Constructor with parameters (deep copies for non-primitive parameters)
    public Aggregation(Fraction fraction, Rectangle[] array, double aDouble) {
        this.fractionField = new Fraction(fraction);  // Deep copy for Fraction
        this.arrayField = new Rectangle[array.length];
        for (int i = 0; i < array.length; i++) {
            this.arrayField[i] = new Rectangle(array[i]);  // Deep copy for Rectangle
        }
        this.doubleField = aDouble;
    }

    // Copy constructor (deep copies for non-primitive parameters)
    public Aggregation(Aggregation other) {
        this.fractionField = new Fraction(other.fractionField);  // Deep copy for Fraction
        this.arrayField = new Rectangle[other.arrayField.length];
        for (int i = 0; i < other.arrayField.length; i++) {
            this.arrayField[i] = new Rectangle(other.arrayField[i]);  // Deep copy for Rectangle
        }
        this.doubleField = other.doubleField;
    }

    // Accessor methods (returning deep copies)
    public Fraction getFractionField() {
        return new Fraction(fractionField);  // Deep copy for Fraction
    }

    // Get method to retrieve a copy of the arrayField
    public Rectangle[] getArrayField() {
    // Create a new array to store a deep copy of the arrayField
        Rectangle[] copyArray = new Rectangle[arrayField.length];
            // Iterate through the elements of arrayField
        for (int i = 0; i < arrayField.length; i++) {
            // Create a new Rectangle object with the same properties as the current arrayField element
            copyArray[i] = new Rectangle(arrayField[i]);  // Deep copy for Rectangle
        }
       // Return the deep copy of the arrayField  
        return copyArray;
    }

    public double getDoubleField() {
        return doubleField;
    }

    // Mutator methods (deep copies for non-primitive parameters)
    public void setFractionField(Fraction fraction) {
        this.fractionField = new Fraction(fraction);  // Deep copy for Fraction
    }

    public void setArrayField(Rectangle[] array) {
        this.arrayField = new Rectangle[array.length];
        for (int i = 0; i < array.length; i++) {
            this.arrayField[i] = new Rectangle(array[i]);  // Deep copy for Rectangle
        }
    }

    public void setDoubleField(double aDouble) {
        this.doubleField = aDouble;
    }

    // toString() and forDeepCopyTesting() methods remain unchanged
    public String toString() {
        // Create a StringBuilder to build the string representation of the Aggregation object
        StringBuilder strB = new StringBuilder("Fraction: " + fractionField.toString());
        // Append the beginning of the array representation to the StringBuilder
        strB.append("; Array: [");
        // Iterate through the arrayField elements, excluding the last one
        int i;
        for (i = 0; i < arrayField.length - 1; i++) {
                // Append each element followed by a comma to the StringBuilder
            strB.append(arrayField[i] + ",");
        }
        // Append the last element of the array followed by the closing bracket to the StringBuilder
        strB.append(arrayField[i] + "]; Double: " + doubleField);

        // Return the final string representation of the Aggregation object
        return strB.toString();
    }

    /**
     * Method needed only to test for a deep copy
     *
     * @param a value to set an element with
     */
    public void forDeepCopyTesting(int a) {
        this.arrayField[0].setLength(a);
    }
}

