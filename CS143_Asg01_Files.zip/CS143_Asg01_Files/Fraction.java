
/**
* @author Aigerim Alykulova
*/

// Define a class named Fraction
public class Fraction {
   
     // Declare private integer fields for numerator and denominator   
    private int numerator;
    private int denominator;

    // No-argument constructor for Fraction class  
    public Fraction() {
        // Set the default numerator to 1
        this.numerator = 1;
        // Set the default denominator to 1
        this.denominator = 1;
        // Call the simplify method to ensure the fraction is in its simplified form
        simplify();
    }

 // Constructor that creates a new Fraction object by copying another Fraction object
    public Fraction(Fraction other) {
        // Set the numerator of the new object to the numerator of the other Fraction object  
        this.numerator = other.numerator;
        // Set the denominator of the new object to the denominator of the other Fraction object
        this.denominator = other.denominator;
        // Call the simplify method to ensure the fraction is in its simplified form
        simplify();
    }

   // Get method to retrieve the numerator of the Fraction
    public int getNum() {
        // Return the value of the numerator    
        return numerator;
    }
   // Get method to retrieve the denominator of the Fraction
    public int getDenom() {
        // Return the value of the numerator
        return denominator;
    }

  // Method to set new values for the numerator and denominator of the Fraction  
    public void set(int n, int d) {
        // Check if the provided denominator is zero
        if (d == 0) {
         // Throw an exception if the denominator is zero, as it is not allowed
            throw new IllegalArgumentException("Denominator cannot be zero.");
        }
         // Set the numerator of the Fraction to the provided value 'n'
        this.numerator = n;
         // Set the denominator of the Fraction to the provided value 'd'
        this.denominator = d;
         // Call the simplify method to ensure the fraction is in its simplified form
        simplify();
    }

// Constructor that creates a new Fraction object with specified numerator and denominator
    public Fraction(int numerator, int denominator) {
    // Check if the provided denominator is zero
        if (denominator == 0) {
           // Throw an exception if the denominator is zero, as it is not allowed    
            throw new IllegalArgumentException("Denominator cannot be zero.");
        }
        // Set the numerator of the new object to the provided value    
        this.numerator = numerator;
        // Set the denominator of the new object to the provided value
        this.denominator = denominator;
        // Call the simplify method to ensure the fraction is in its simplified form    
        simplify();
    }

    // Constructor that creates a new Fraction object representing a mixed fraction   
    public Fraction(int whole, int numerator, int denominator) {
        // Check if the provided denominator is zero   
        if (denominator == 0) {
        // Throw an exception if the denominator is zero, as it is not allowed
            throw new IllegalArgumentException("Denominator cannot be zero.");
        }

        // Check if the provided numerator or denominator is negative
        if (numerator < 0 || denominator < 0) {
         // Throw an exception if either numerator or denominator is negative
            throw new IllegalArgumentException("Numerator and denominator must not be negative.");
        }

        // Calculate the adjusted numerator based on the whole part, numerator, and denominator
        // If the whole part is non-negative, calculate as whole * denominator + numerator
        // If the whole part is negative, calculate as whole * denominator - numerator
        this.numerator = whole >= 0 ? whole * denominator + numerator : whole * denominator - numerator;
        // Set the denominator of the new object to the provided value
        this.denominator = denominator;
        // Call the simplify method to ensure the fraction is in its simplified form
        simplify();
    }

     // Method to add the current Fraction object to another Fraction object 'obj'   
    public Fraction add(Fraction obj) {
        // Calculate the common denominator for addition
        int commonDenominator = this.denominator * obj.denominator / gcd(this.denominator, obj.denominator);
        // Calculate the sum of numerators with the common denominator
        int sumNumerator = this.numerator * (commonDenominator / this.denominator)
                + obj.numerator * (commonDenominator / obj.denominator);
        // Create a new Fraction object with the calculated sumNumerator and commonDenominator
         return new Fraction(sumNumerator, commonDenominator);
    }

    // Subtraction method to subtract another Fraction object 'obj' from the current Fraction object
    public Fraction subtract(Fraction obj) {
        // Calculate the common denominator for subtraction    
        int commonDenominator = this.denominator * obj.denominator / gcd(this.denominator, obj.denominator);
        // Calculate the difference of numerators with the common denominator
        int diffNumerator = this.numerator * (commonDenominator / this.denominator)
                - obj.numerator * (commonDenominator / obj.denominator);
        // Create a new Fraction object with the calculated diffNumerator and commonDenominator          
        return new Fraction(diffNumerator, commonDenominator);
    }

// Multiplication method to multiply the current Fraction object by another Fraction object 'obj'
    public Fraction multiply(Fraction obj) {
    // Create a new Fraction object with the product of numerators and denominators
        return new Fraction(this.numerator * obj.numerator, this.denominator * obj.denominator);
    }

// Division method to divide the current Fraction object by another Fraction object 'obj'
    public Fraction divide(Fraction obj) {
     // Check if the numerator of the divisor 'obj' is zero (avoid division by zero)
        if (obj.numerator == 0) {
            // Throw an exception if attempting to divide by zero
            throw new IllegalArgumentException("Cannot divide by zero.");
        }
         // Create a new Fraction object with the product of numerators and denominators
        return new Fraction(this.numerator * obj.denominator, this.denominator * obj.numerator);
    }
// Method to convert the Fraction object into a string representation    
    public String toString() {
        // Calculate the whole part and remaining numerator for mixed fractions    
        int wholePart = numerator / denominator;
        int remainingNumerator = Math.abs(numerator) % denominator;
    
       // Check if the numerator is zero     
        if (numerator == 0) {
            // Return the string representation for a fraction with zero numerator
            return numerator + "/" + denominator + " or " + numerator;
            // Return the string representation for a proper fraction
        } else if (Math.abs(numerator) < Math.abs(denominator)) {
          // Return the string representation for a proper fraction
            return numerator + "/" + denominator;
        } else {
            // Return the string representation for a mixed fraction     
            return String.format("%d/%d or %d and %d/%d", numerator, denominator, wholePart, remainingNumerator, denominator);
        }
    }

    

    // Less method to check if the current fraction is less than another fraction 'obj'
    public boolean less(Fraction obj) {
        // Compare fractions based on cross multiplication    
        return this.numerator * obj.denominator < obj.numerator * this.denominator;
    }

    // More method to check if the current fraction is greater than another fraction 'obj'   
    public boolean more(Fraction obj) {
        // Compare fractions based on cross multiplication
        return this.numerator * obj.denominator > obj.numerator * this.denominator;
    }

    // Equals method to check if the current fraction is equal to another fraction 'obj'
    public boolean equals(Fraction obj) {
        // Compare fractions based on cross multiplication
        return this.numerator * obj.denominator == obj.numerator * this.denominator;
    }

    // Private method to find the greatest common divisor using Euclid's algorithm 
    private int gcd(int a, int b) {
        if (b == 0) {
            return a;
        } else {
            return gcd(b, a % b);
        }
    }

    // Simplify method to simplify the current fraction by dividing both numerator and denominator by their common GCD
    private void simplify() {
        // Find the greatest common divisor of the absolute values of numerator and denominator
        int commonGCD = gcd(Math.abs(numerator), Math.abs(denominator));
      // Divide both numerator and denominator by their common GCD  
        numerator /= commonGCD;
        denominator /= commonGCD;

      // Ensure the sign is on the numerator if the denominator is negative  
        if (denominator < 0) {
            numerator = -numerator;
            denominator = -denominator;
        }
    }
}

